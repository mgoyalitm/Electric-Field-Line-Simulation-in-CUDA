#pragma once

#include "RenderData.hpp"

namespace Rendering {

	RenderData::RenderData(Physics::Pole* poles, Geometry::Vector3f** field_lines, int* field_line_lengths)
		: poles(poles), field_lines(field_lines), field_line_lengths(field_line_lengths) {
	}

	void destroy(RenderData data) {

		if (data.poles != nullptr)	{
			delete[] data.poles;
		}

		for (int i = 0; i < Constants::FieldLinesTotal; i++) {
			if (data.field_lines != nullptr) {
				delete[] data.field_lines[i];
			}
		}

		if (data.field_line_lengths != nullptr)	{
			delete[] data.field_line_lengths;
		}
	}

	inline bool validate(RenderData data) {
		return data.poles != nullptr && data.field_lines != nullptr && data.field_line_lengths != nullptr;
	}

}