#include <algorithm>
#include <execution> 
#include "Pole.cuh"

namespace Physics {
	
	void animate_poles_cpu(Pole* poles, int pole_count) {
		for (int i = 0; i < Constants::AnimationSteps; i++)
		{
			std::for_each(std::execution::par, poles, poles + Constants::PolesCount, [&](Physics::Pole& pole) {
				Geometry::Vector3f acceleration = naive_field_strength(poles, Constants::PolesCount, pole.position) * (pole.strength / pole.mass);
				pole.velocity += acceleration * Constants::dt;
				pole.position += pole.velocity * Constants::dt;
				});
		}
	}
}